//Alumno: Gerard Calderón Anyosa
//Código: 20190200

//inclusion de librerias
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    int N=8, i, j;
    int **matriz_in;                                                      //Declaracion matriz de entrada(doble puntero)
    int **matriz_out;                                                     //Declaracion matriz de salida(doble puntero)
    int size_in = 2*N+1;
    matriz_in = (int**)malloc(size_in*sizeof(int*));                      //Asignación de espacion en la memoria dinámica

    struct timespec ti, tf;
    double elapsed;

    clock_gettime(CLOCK_REALTIME, &ti);                                   //se captura el tiempo de inicio

    for(i = 0; i < size_in ; i++ ){
        matriz_in[i] = (int*)malloc(size_in*sizeof(int));
    }
    matriz_out = (int**)malloc(N*sizeof(int*));                           //Asignación de espacion en la memoria dinámica
    for(i = 0; i <= N ; i++ ){
        matriz_out[i] = (int*)malloc(N*sizeof(int));
    }
    for(i = 0; i< size_in; i++ ){
        for(j = 0; j< size_in; j++ ){
             matriz_in[i][j] = i*size_in+j;
        }
    }

    for(i = 0; i <= N; i++ ){                                          
        for(j = 0; j <= N; j++ ){
             matriz_out[i][j] = matriz_in[2*i][2*j];                      //Se realiza el downsampling, se utiliza el factor D = 2 para eliminar filas y columnas impares
        }
        free(matriz_out[i]);
        free(matriz_in[2*i]);
        if( i!= N){
          free(matriz_in[2*i+1]);
        } 
    }
    free(matriz_out);
    free(matriz_in);

    clock_gettime(CLOCK_REALTIME, &tf);                                   //Se captura el tiempo en el que finaliza
    elapsed =  (tf.tv_nsec - ti.tv_nsec);                                 //Se calcula el tiempo transcurrido
    
    printf("El tiempo en nanosegundos que toma la función en C es %lf\n", elapsed);
    
    
    return 0;
}